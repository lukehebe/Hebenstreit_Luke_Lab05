public class RPSGame {
    private int CWins; // Computer Wins
    private int UWins; // User Wins
    private int Ties; // Ties

    static final int ROCK = 1;
    static final int PAPER = 2;
    static final int SCISSORS = 3;

    // Constructor
    public RPSGame(int init){
        CWins = init;
        UWins = init;
        Ties = init;
    }

    public void setCWins(int cw){
        CWins = cw;
    }
    public void setUWins(int uw){
        UWins = uw;
    }
    public void setTies(int t){
        Ties = t;
    }
    public int getCWins(){
        return CWins;
    }
    public int getUWins(){
        return UWins;
    }
    public int getTies(){
        return Ties;
    }
    public void display(){
        System.out.println("Comp Wins "+CWins+" User Wins "+UWins+" Ties"+Ties);
    }

    public int generateComputerPlay(){
        Random r = new Random();
        return (int)(r.nextDouble() * 3 + 1);
    }
    public boolean findWinner(int compMove, int userMove){
        if (compMove == userMove)
            setTies(getTies()+1);
        else
        if (compMove == ROCK){
            if (userMove == PAPER)
                setUWins(getUWins()+1);
            else
                setCWins(getCWins()+1);
        }else{
            if (compMove == PAPER){
                if (userMove == SCISSORS)
                    setUWins(getUWins()+1);
                else
                    setCWins(getCWins()+1);
            }else{
                if (compMove == SCISSORS){
                    if (userMove == ROCK)
                        setUWins(getUWins()+1);
                    else
                        setCWins(getCWins()+1);
                }
            }
        }
        return true;
    }
    public String getOptionComp(int op){
        String s="";
        switch(op){
            case 1 : s="ROCK"; break;
            case 2 : s="PAPER"; break;
            default : s="SCISSORS"; break;
        }
        return s;
    }
}